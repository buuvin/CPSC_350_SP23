Name: Bhuvan Balagar
Student ID: 2430998
Student email: balagar@chapman.edu
Course Number & Section: CPSC 350-04

Assignment: Programming Assignment 2: Not So Super Mario Bros

List of files submitted for assignment
1. Mario.cpp
2. Mario.h
3. Level.cpp
4. Level.h
5. World.cpp
6. World.h
7. main.cpp
8. input.txt
9. README.md

Code Limitations: if the percentage of items on the grid is below the percentage one tile takes up on the grid, it will not be placed on the grid

References: 
Rene German

appending to a file: http://www.learningaboutelectronics.com/Articles/How-to-append-to-a-file-in-C++.php#:~:text=In%20order%20for%20us%20to,explain%20in%20the%20next%20paragraph.&text=With%20the%20full%20line%2C%20ofstream,append%20contents%20to%20the%20file.
